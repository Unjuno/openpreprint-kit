# OpenPreprint Kit: GitHub上の論文・研究データを検証可能にする公開キット — v1

Version-specific release: (local bundle)

Paper license: CC-BY-4.0

Paper SHA-256: 0860b735379fb1b9b223f5d535442dae8421f456d7ae1c6bf6ce8d3141a1b07c

This release includes machine-readable citation metadata and a checksum manifest.
**Checksums alone are not time evidence. Verify any timestamp.tsq/timestamp.tsr sidecars with an independently selected trust policy. Public access time is not proven.**
